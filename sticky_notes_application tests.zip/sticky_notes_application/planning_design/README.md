# Sticky Notes Application — Design Diagram

This folder contains all design artefacts for the Sticky Notes Django application.

## Contents

- **use_case_diagram.png / .xml** — shows main user interactions: create, edit, delete, view, and mark notes as complete.

The diagram was created using draw.io (diagrams.net).
